package spell;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class SpellCheckTest3 {

	public SpellCheck test = new SpellCheck();

	@Test
	public void testFindWord() {
		SpellCheck sc=new SpellCheck();
		Phonetic ph=new Phonetic();
		ph.codeDictionary();
		sc.dictionary();
		boolean output=test.findWord("�����");
		assertEquals(true,output);
	}


	@Test
	public void testLetterPlus() {
		SpellCheck sc=new SpellCheck();
		Phonetic ph=new Phonetic();
		ph.codeDictionary();
		sc.dictionary();
		ArrayList<String> output2=new ArrayList<String>();
		output2 = test.letterPlus("�����");
		ArrayList<String> output22=new ArrayList<String>();
		output22.add("����");
		assertArrayEquals( output22.toArray(),output2.toArray());
	}
	@Test
	public void testLetterLess(){
		SpellCheck sc= new SpellCheck();
		Phonetic ph=new Phonetic();
		ph.codeDictionary();
		sc.dictionary();
		ArrayList<String> output1=new ArrayList<String>();
		output1 = test.letterLess("��");
		ArrayList<String> output11=new ArrayList<String>();
		output11.add("���");
		output11.add("���");
		output11.add("���");
		assertArrayEquals( output11.toArray(),output1.toArray());



	}
	@Test
	public void testSuggestions(){
		SpellCheck sc= new SpellCheck();
		Phonetic ph=new Phonetic();
		ph.codeDictionary();
		sc.dictionary();
		ArrayList<String> output7=new ArrayList<String>();
		output7 = test.suggestions("��");
		ArrayList<String> output77=new ArrayList<String>();
		output77.add("��");
		output77.add("���");
		output77.add("��");
		output77.add("��");
		output77.add("���");
		output77.add("��");
		output77.add("��");
		output77.add("��");
		output77.add("���");
		assertArrayEquals( output77.toArray(),output7.toArray());

	}
@Test
public void testWrongLetter(){
	SpellCheck sc= new SpellCheck();
	Phonetic ph=new Phonetic();
	ph.codeDictionary();
	sc.dictionary();
	ArrayList<String> output3=new ArrayList<String>();
	output3 = test.wrongLetter("����");
	ArrayList<String> output33=new ArrayList<String>();
	output33.add("����");
    assertArrayEquals( output33.toArray(),output3.toArray());

}

//@Test
public void testLettersSwapped(){
	SpellCheck sc= new SpellCheck();
	Phonetic ph=new Phonetic();
	ph.codeDictionary();
	sc.dictionary();
	ArrayList<String> output4=new ArrayList<String>();
	output4 = test.wrongLetter("�����");
	ArrayList<String> output44=new ArrayList<String>();
	output44.add("�����");
    assertArrayEquals( output44.toArray(),output4.toArray());

}

@Test
public void testPhonetic(){
	SpellCheck sc= new SpellCheck();
	sc.dictionary();
	ArrayList<String> output6=new ArrayList<String>();
	output6= test.phonetic("����");
	ArrayList<String> output66=new ArrayList<String>();
	output66.add("����");
    assertArrayEquals( output66.toArray(),output6.toArray());
}
}